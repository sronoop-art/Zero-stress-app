# PNG Icons — required files

The app no longer uses emoji for buttons, menu tiles and status icons.
Instead it loads PNG files from `app/src/main/res/drawable/`.

## How to add the files

1. Make each PNG a **square**, solid white icon on a transparent background
   (a single color is best because the code can tint it with any theme color).
2. Recommended size: **96x96 px** (Android scales it down for each density;
   if you want perfect sharpness also provide 48/72/96/144/192 px versions in
   `drawable-mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi` — but a single 96x96 in
   `drawable/` is enough to build).
3. Save each file with the **exact lowercase name** shown below, directly in
   `app/src/main/res/drawable/`.
4. Build → the app picks them up automatically via `R.drawable.<name>`.

Good sources for white icon PNGs: [fonts.google.com/icons](https://fonts.google.com/icons)
(choose "Download → PNG", color white) or any icon pack.

## Menu tile icons (Player + Admin dashboards)

| File name | Used for |
|---|---|
| `ic_menu_calendar.png` | Schedule / Seasons tile |
| `ic_menu_trophy.png` | Leaderboard tile |
| `ic_menu_chat.png` | Team Chat tile |
| `ic_menu_mic.png` | Voice Chat tile |
| `ic_menu_call.png` | Voice Call tile (admin) |
| `ic_menu_person.png` | My Profile tile + avatar placeholder |
| `ic_menu_friends.png` | Friends tile |
| `ic_menu_medal.png` | Seasons + Achievements tiles |
| `ic_menu_announce.png` | Announcements / Broadcast tile |
| `ic_menu_gift.png` | Daily Rewards tile |
| `ic_menu_fire.png` | Daily Challenges tile |
| `ic_menu_ticket.png` | Battle Pass tile |
| `ic_menu_sparkles.png` | My Titles tile |
| `ic_menu_chart.png` | Performance tile |
| `ic_menu_bell.png` | Notifications / Notify tile + header bell |
| `ic_menu_settings.png` | Settings tile |
| `ic_menu_logout.png` | Logout tile |
| `ic_menu_edit.png` | Daily Input / Edit tile |
| `ic_menu_people.png` | All Stats / Manage players icon |
| `ic_menu_channels.png` | Voice Channels admin tile |
| `ic_menu_crown.png` | Admin crown in top bar |

## Title badges (My Titles screen - 8 rank titles)

Shown as round badges on the My Titles screen. These are displayed **with their
own colors** (no tint), so use the real rank colors (bronze, silver, gold...).
Recommended: square PNG, 128x128 px, transparent background.

| File name | Title | Unlocks at |
|---|---|---|
| `ic_title_bronze.png` | Bronze | 600 score |
| `ic_title_silver.png` | Silver | 1,200 score |
| `ic_title_gold.png` | Gold | 2,000 score |
| `ic_title_platinum.png` | Platinum | 3,000 score |
| `ic_title_diamond.png` | Diamond | 4,000 score |
| `ic_title_heroic.png` | Heroic | 5,000 score |
| `ic_title_master.png` | Master | 7,000 score |
| `ic_title_grandmaster.png` | Grandmaster | 10,000 score |

Total: **8 PNG files**. These are optional - if a badge PNG is missing the app
shows a colored medallion with the rank letter instead (no build error).

## Avatar frames (My Profile screen - 8 rank frames)

The player's avatar on My Profile gets a decorative frame based on the
equipped title. A player whose title is Bronze automatically wears the
bronze frame PNG. Drawn over a circular 88dp avatar, scaled to 112dp -
so make each frame a **square PNG, 256x256 px, transparent background,
with a transparent circular hole in the middle** (a ring).

| File name | Frame for title |
|---|---|
| `frame_bronze.png` | Bronze |
| `frame_silver.png` | Silver |
| `frame_gold.png` | Gold |
| `frame_platinum.png` | Platinum |
| `frame_diamond.png` | Diamond |
| `frame_heroic.png` | Heroic |
| `frame_master.png` | Master |
| `frame_grandmaster.png` | Grandmaster |

Total: **8 PNG files**. Optional - when a frame PNG is missing, a colored
ring in the title's color is drawn instead (no build error). The frame only
appears after the player equips that title on the My Titles screen.

## Small action icons

| File name | Used for |
|---|---|
| `ic_action_delete.png` | Delete buttons (chat clear, schedule, season, channel) |
| `ic_action_send.png` | Chat send button |
| `ic_action_pause.png` | Disable/pause voice channel |

Total: **24 PNG files**. If any file is missing the build fails with
`Unresolved reference: ic_menu_xxx` — just add the missing PNG and rebuild.

## Tip

One easy way to generate all of them: download the Material Symbols you like
as white PNGs and rename them to the names above. Only the file name matters —
any square icon works.
