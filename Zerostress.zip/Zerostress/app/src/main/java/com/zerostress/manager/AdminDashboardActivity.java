package com.zerostress.manager;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminDashboardActivity extends AppCompatActivity {

    private FirebaseFirestore db;
    private FirebaseAuth auth;
    private ProgressBar progressBar;
    private TextView tvAdminName, tvTotalPlayers, tvActiveMatches;
    private RecyclerView rvPlayers;
    private PlayerAdapter adapter;
    private List<DocumentSnapshot> players = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_dashboard);

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();

        tvAdminName = findViewById(R.id.tvAdminName);
        tvTotalPlayers = findViewById(R.id.tvTotalPlayers);
        tvActiveMatches = findViewById(R.id.tvActiveMatches);
        progressBar = findViewById(R.id.progressBar);
        rvPlayers = findViewById(R.id.rvPlayers);

        if (rvPlayers != null) {
            rvPlayers.setLayoutManager(new LinearLayoutManager(this));
            adapter = new PlayerAdapter();
            rvPlayers.setAdapter(adapter);
        }

        // Navigation buttons
        findViewById(R.id.btnPlayerManagement).setOnClickListener(v -> showPlayerList());
        findViewById(R.id.btnDailyInput).setOnClickListener(v -> startActivity(new Intent(this, DailyInputActivity.class)));
        findViewById(R.id.btnAnnouncements).setOnClickListener(v -> showAnnouncementOrScheduleDialog());
        findViewById(R.id.btnLeaderboard).setOnClickListener(v -> startActivity(new Intent(this, LeaderboardActivity.class)));
        findViewById(R.id.btnChat).setOnClickListener(v -> startActivity(new Intent(this, ChatActivity.class)));
        findViewById(R.id.btnVoice).setOnClickListener(v -> startActivity(new Intent(this, VoiceActivity.class)));
        findViewById(R.id.btnSeasons).setOnClickListener(v -> startActivity(new Intent(this, ManageSeasonsActivity.class)));
        findViewById(R.id.btnProfile).setOnClickListener(v -> startActivity(new Intent(this, ViewAllPlayersStatsActivity.class)));
        
        // New admin features
        findViewById(R.id.btnNotifications).setOnClickListener(v -> startActivity(new Intent(this, SendNotificationActivity.class)));
        
        findViewById(R.id.btnSettings).setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            auth.signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        loadAdminInfo();
        loadPlayers();
    }

    private void loadAdminInfo() {
        String userId = auth.getUid();
        if (userId == null) return;
        
        db.collection("players").document(userId).get()
            .addOnSuccessListener(doc -> {
                if (doc.exists()) {
                    tvAdminName.setText(doc.getString("name"));
                }
            });

        db.collection("players").get()
            .addOnSuccessListener(query -> {
                tvTotalPlayers.setText(String.valueOf(query.size()));
            });

        db.collection("match_logs").get()
            .addOnSuccessListener(query -> {
                tvActiveMatches.setText(String.valueOf(query.size()));
            });
    }

    private void loadPlayers() {
        if (progressBar != null) progressBar.setVisibility(View.VISIBLE);
        
        db.collection("players").get()
            .addOnSuccessListener(query -> {
                if (progressBar != null) progressBar.setVisibility(View.GONE);
                players.clear();
                for (DocumentSnapshot doc : query.getDocuments()) {
                    players.add(doc);
                }
                if (adapter != null) adapter.notifyDataSetChanged();
            })
            .addOnFailureListener(e -> {
                if (progressBar != null) progressBar.setVisibility(View.GONE);
                Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
    }

    private void showPlayerList() {
        if (players.isEmpty()) {
            Toast.makeText(this, "Loading players...", Toast.LENGTH_SHORT).show();
            loadPlayers();
        } else {
            if (rvPlayers != null) {
                rvPlayers.setVisibility(rvPlayers.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        }
    }

    private void showAnnouncementOrScheduleDialog() {
        // Admin picks: Schedule a match OR broadcast an announcement
        String[] options = {
            "📋 Create Match Schedule",
            "📢 Broadcast Announcement"
        };
        new AlertDialog.Builder(this)
            .setTitle("What do you want to do?")
            .setItems(options, (d, which) -> {
                if (which == 0) showEditScheduleDialog();
                else showAnnouncementDialog();
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void showAnnouncementDialog() {
        EditText input = new EditText(this);
        input.setHint("Type announcement...");
        input.setTextColor(0xFFFFFFFF);
        input.setHintTextColor(0xFF718096);
        input.setMinLines(3);

        new AlertDialog.Builder(this)
            .setTitle("📢 Broadcast Announcement")
            .setView(input)
            .setPositiveButton("Send", (d, w) -> {
                String text = input.getText().toString().trim();
                if (!TextUtils.isEmpty(text)) {
                    Map<String, Object> ann = new HashMap<>();
                    ann.put("text", text);
                    ann.put("author", "Admin");
                    ann.put("timestamp", System.currentTimeMillis());
                    db.collection("announcements").add(ann)
                        .addOnSuccessListener(v -> {
                            Toast.makeText(this, "📢 Announcement sent to all players!", Toast.LENGTH_SHORT).show();
                            // Cloud Function pushes FCM automatically on new announcement
                        });
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void showEditScheduleDialog() {
        String[] matchTypes = {"Ranked", "Custom", "Tournament", "Friendly"};
        
        // Build dialog view with three inputs
        LinearLayout dialogView = new LinearLayout(this);
        dialogView.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        dialogView.setPadding(pad, pad, pad, 0);

        EditText etMatchTitle = new EditText(this);
        etMatchTitle.setHint("Match Title (e.g., Squad Battle #1)");
        etMatchTitle.setTextColor(0xFFFFFFFF);
        dialogView.addView(etMatchTitle);

        EditText etMatchTime = new EditText(this);
        etMatchTime.setHint("Date & Time (e.g., 2026-09-10 20:00)");
        etMatchTime.setTextColor(0xFFFFFFFF);
        dialogView.addView(etMatchTime);

        EditText etMatchType = new EditText(this);
        etMatchType.setHint("Type: Ranked / Custom / Tournament / Friendly");
        etMatchType.setTextColor(0xFFFFFFFF);
        dialogView.addView(etMatchType);

        new AlertDialog.Builder(this)
            .setTitle("📋 Add Match Schedule")
            .setView(dialogView)
            .setPositiveButton("Create", (d, w) -> {
                String title = etMatchTitle.getText().toString().trim();
                String timeStr = etMatchTime.getText().toString().trim();
                String type = etMatchType.getText().toString().trim();
                
                if (TextUtils.isEmpty(title)) {
                    Toast.makeText(this, "Title required", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Parse datetime
                long matchTimeMs = System.currentTimeMillis();
                if (!TextUtils.isEmpty(timeStr)) {
                    try {
                        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault());
                        java.util.Date parsedDate = sdf.parse(timeStr);
                        if (parsedDate != null) matchTimeMs = parsedDate.getTime();
                    } catch (java.text.ParseException e) {
                        // If parse fails, fall back to 24h from now
                        matchTimeMs = System.currentTimeMillis() + 24 * 60 * 60 * 1000;
                    }
                }

                Map<String, Object> schedule = new HashMap<>();
                schedule.put("title", title);
                schedule.put("description", type.isEmpty() ? "Custom Match" : type);
                schedule.put("matchTime", matchTimeMs);
                schedule.put("dateTime", TextUtils.isEmpty(timeStr) ? "TBD" : timeStr);
                schedule.put("status", "Upcoming");
                schedule.put("type", type.isEmpty() ? "Custom" : type);
                schedule.put("createdAt", System.currentTimeMillis());
                schedule.put("createdBy", auth.getUid());
                
                db.collection("match_schedules").add(schedule)
                    .addOnSuccessListener(v -> {
                        Toast.makeText(this, "✅ Schedule created!", Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    // Player Adapter with Edit Name/Role
    class PlayerAdapter extends RecyclerView.Adapter<PlayerAdapter.VH> {
        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_player, parent, false);
            return new VH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull VH holder, int position) {
            DocumentSnapshot doc = players.get(position);
            holder.tvName.setText(doc.getString("name"));
            String role = doc.getString("role");
            String status = doc.getString("status");
            String gameRole = doc.getString("gameRole");
            String gameRoleEmoji = "";
            if (gameRole != null && !gameRole.isEmpty()) {
                switch (gameRole) {
                    case "Rusher": gameRoleEmoji = "⚔️ "; break;
                    case "Sniper": gameRoleEmoji = "🎯 "; break;
                    case "IGL": gameRoleEmoji = "👑 "; break;
                    case "Supporter": gameRoleEmoji = "🛡️ "; break;
                    case "Bomber": gameRoleEmoji = "💣 "; break;
                }
            }
            holder.tvRole.setText(gameRoleEmoji + (role != null ? role : "player") + " • " + (status != null ? status : "pending"));
            Long score = doc.getLong("score");
            holder.tvScore.setText(String.valueOf(score != null ? score : 0));

            holder.itemView.setOnClickListener(v -> {
                String[] options = {
                    "✏️ Edit Name",
                    "👑 Change Admin Role",
                    "🎮 Set Game Role",
                    "✅ Approve",
                    "❌ Reject",
                    "🚫 Ban",
                    "🗑️ Delete Player"
                };
                new AlertDialog.Builder(AdminDashboardActivity.this)
                    .setTitle(doc.getString("name"))
                    .setItems(options, (d, which) -> {
                        switch (which) {
                            case 0: showEditNameDialog(doc); break;
                            case 1: showChangeRoleDialog(doc); break;
                            case 2: showGameRoleDialog(doc); break;
                            case 3: updateStatus(doc.getId(), "approved"); break;
                            case 4: updateStatus(doc.getId(), "rejected"); break;
                            case 5: updateStatus(doc.getId(), "banned"); break;
                            case 6: deletePlayer(doc.getId(), doc.getString("name")); break;
                        }
                    })
                    .show();
            });
        }

        @Override
        public int getItemCount() { return players.size(); }

        class VH extends RecyclerView.ViewHolder {
            TextView tvName, tvRole, tvScore;
            VH(View v) {
                super(v);
                tvName = v.findViewById(R.id.tvName);
                tvRole = v.findViewById(R.id.tvRole);
                tvScore = v.findViewById(R.id.tvScore);
            }
        }
    }

    // Edit Player Name Dialog
    private void showEditNameDialog(DocumentSnapshot player) {
        EditText input = new EditText(this);
        input.setText(player.getString("name"));
        input.setSelection(input.getText().length());

        new AlertDialog.Builder(this)
            .setTitle("✏️ Edit Player Name")
            .setView(input)
            .setPositiveButton("Save", (d, w) -> {
                String newName = input.getText().toString().trim();
                if (!TextUtils.isEmpty(newName)) {
                    db.collection("players").document(player.getId())
                        .update("name", newName)
                        .addOnSuccessListener(v -> {
                            Toast.makeText(this, "Name updated to: " + newName, Toast.LENGTH_SHORT).show();
                            loadPlayers();
                        })
                        .addOnFailureListener(e -> {
                            Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        });
                }
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    // Change Role Dialog
    private void showChangeRoleDialog(DocumentSnapshot player) {
        String currentRole = player.getString("role");
        if (currentRole == null) currentRole = "player";

        String[] roles = {"player", "moderator", "admin"};
        int checkedItem = 0;
        for (int i = 0; i < roles.length; i++) {
            if (roles[i].equals(currentRole)) {
                checkedItem = i;
                break;
            }
        }

        new AlertDialog.Builder(this)
            .setTitle("👑 Change Role for " + player.getString("name"))
            .setSingleChoiceItems(roles, checkedItem, (dialog, which) -> {
                String selectedRole = roles[which];
                db.collection("players").document(player.getId())
                    .update("role", selectedRole)
                    .addOnSuccessListener(v -> {
                        Toast.makeText(this, "Role updated to: " + selectedRole, Toast.LENGTH_SHORT).show();
                        loadPlayers();
                        dialog.dismiss();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    });
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    // Game Role Dialog (Rusher, Sniper, IGL, Supporter, Bomber)
    private void showGameRoleDialog(DocumentSnapshot player) {
        String currentGameRole = player.getString("gameRole");
        if (currentGameRole == null) currentGameRole = "";

        String[] gameRoles = {"Rusher", "Sniper", "IGL", "Supporter", "Bomber", "None"};
        String[] gameRoleEmojis = {"⚔️", "🎯", "👑", "🛡️", "💣", "❌"};
        int checkedItem = 5; // Default: None
        for (int i = 0; i < gameRoles.length; i++) {
            if (gameRoles[i].equals(currentGameRole)) {
                checkedItem = i;
                break;
            }
        }

        // Build display names with emojis
        String[] displayRoles = new String[gameRoles.length];
        for (int i = 0; i < gameRoles.length; i++) {
            displayRoles[i] = gameRoleEmojis[i] + " " + gameRoles[i];
        }

        new AlertDialog.Builder(this)
            .setTitle("🎮 Set Game Role for " + player.getString("name"))
            .setSingleChoiceItems(displayRoles, checkedItem, (dialog, which) -> {
                String selectedGameRole = which == 5 ? "" : gameRoles[which];
                String emoji = which == 5 ? "" : gameRoleEmojis[which];
                db.collection("players").document(player.getId())
                    .update("gameRole", selectedGameRole)
                    .addOnSuccessListener(v -> {
                        Toast.makeText(this, "Game role set to: " + emoji + " " + 
                            (selectedGameRole.isEmpty() ? "None" : selectedGameRole), 
                            Toast.LENGTH_SHORT).show();
                        loadPlayers();
                        dialog.dismiss();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    });
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    private void updateStatus(String uid, String status) {
        db.collection("players").document(uid).update("status", status)
            .addOnSuccessListener(v -> {
                Toast.makeText(this, "Status updated!", Toast.LENGTH_SHORT).show();
                loadPlayers();
            });
    }

    private void deletePlayer(String uid, String name) {
        new AlertDialog.Builder(this)
            .setTitle("⚠️ Delete Player")
            .setMessage("Are you sure you want to delete '" + name + "'?\n\nThis action cannot be undone!")
            .setPositiveButton("Delete", (d, w) -> {
                db.collection("players").document(uid).delete()
                    .addOnSuccessListener(v -> {
                        Toast.makeText(this, "Player deleted!", Toast.LENGTH_SHORT).show();
                        loadPlayers();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
            })
            .setNegativeButton("Cancel", null)
            .show();
    }
}
